#ifndef __MMIND_IOCTL
#define __MMIND_IOCTL

#include <linux/ioctl.h>

#define MMIND_IOC_MAGIC  'k'
#define MMIND_REMAINING	_IO(MMIND_IOC_MAGIC, 0)
#define MMIND_ENDGAME	_IO(MMIND_IOC_MAGIC, 1)
#define MMIND_NEWGAME	_IOW(MMIND_IOC_MAGIC, 2, char*)
#define MMIND_IOC_MAXNR 2

#endif