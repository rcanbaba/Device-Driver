#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/init.h>
#include <linux/cred.h>
#include <linux/uidgid.h>
#include <linux/kernel.h>   /* printk() */
#include <linux/slab.h>     /* kmalloc() */
#include <linux/fs.h>       /* everything... */
#include <linux/errno.h>    /* error codes */
#include <linux/types.h>    /* size_t */
#include <linux/proc_fs.h>
#include <linux/fcntl.h>    /* O_ACCMODE */
#include <linux/seq_file.h>
#include <linux/cdev.h>
#include <linux/sched.h>
#include <linux/file.h>
#include <asm/switch_to.h>      /* cli(), *_flags */
#include <asm/uaccess.h>    /* copy_*_user */


//  check if linux/uaccess.h is required for copy_*_user
//instead of asm/uaccess
//required after linux kernel 4.1+ ?
#ifndef __ASM_ASM_UACCESS_H
    #include <linux/uaccess.h>
#endif


#include "mastermind_ioctl.h"

#define MMIND_MAJOR 0
#define MMIND_NR_DEVS 1
#define MMIND_MAX_GUESSES 10
#define MMIND_NUMBER "4325"


int mmind_major = MMIND_MAJOR;
int mmind_minor = 0;
int mmind_max_guesses = MMIND_MAX_GUESSES;
int mmind_nr_devs = MMIND_NR_DEVS;
char *mmind_number = MMIND_NUMBER;

module_param(mmind_major, int, S_IRUGO);
module_param(mmind_minor, int, S_IRUGO);
module_param(mmind_max_guesses, int, S_IRUGO);
module_param(mmind_nr_devs, int, S_IRUGO);
module_param(mmind_number, charp, S_IRUGO);

MODULE_AUTHOR("Alessandro Rubini, Jonathan Corbet");
MODULE_LICENSE("Dual BSD/GPL");

struct guess_node
{
    struct guess_node *next;

    char message[16];
    char *guess;
    
    char in_place_digits[2];
    char out_of_place_digits[2];
    
    int guess_count;
};

struct mmind_dev {
    struct guess_node *head;
    struct guess_node *tail;

    char *mmind_number;

    unsigned long size;

    struct semaphore sem;
    struct cdev cdev;
};

struct mmind_dev *mmind_devices;

void analyze_guess(struct guess_node *node){
    int i, j;
    int in_place = 0, out_of_place = 0;
    int checked_first[4] = {0, 0, 0, 0};
    int checked_second[4] = {0, 0, 0, 0};
    for(i = 0; i < 4; i++){
        if (mmind_number[i] == node->guess[i]){
            in_place ++;
            checked_first[i] = 1;
            checked_second[i] = 1;
        }
    }
    
    for(i = 0; i < 4; i++){
        if(checked_first[i])
            continue;
        for(j = 0; j < 4; j++){
            if(checked_second[j])
                continue;
            if (mmind_number[i] == node->guess[j]){
                out_of_place ++;
                checked_first[i] = 1;
                checked_second[j] = 1;
                break;
            }
        }
    }

    printk(KERN_NOTICE "%d, %d", in_place, out_of_place);
    node->in_place_digits[0] = in_place + '0';
    node->in_place_digits[1] = '+';

    node->out_of_place_digits[0] = out_of_place + '0';
    node->out_of_place_digits[1] = '-';
}

void guess_count_to_string(struct guess_node *node){
    int count = node->guess_count;
    int i = 14, val = 0;
    while(count > 0 || i > 10){
        val = count % 10;
        if (count == 0){ 
            node->message[i] = '0';
        }
        else {
            node->message[i] = val + '0';
        } 
        count = count / 10;
        i--;
    }
}


/*
    dev: input struct
    guess: user guess
    count: size of the user guess
*/
void make_guess(struct mmind_dev *dev, char* guess, size_t count){
    int i;
    struct guess_node *node = kmalloc(sizeof(struct guess_node), GFP_KERNEL);
    node->next = NULL;
    node->guess = kmalloc(sizeof(char) * (count), GFP_KERNEL);
    strncpy(node->guess, guess, count);

    analyze_guess(node);
    for(i = 0; i < 4; i++)
        node->message[i] = node->guess[i];
    node->message[4] = ' ';
    for(i = 5; i < 7; i++)
        node->message[i] = node->in_place_digits[i - 5];
    node->message[7] = ' ';
    for(i = 8; i < 10; i++)
        node->message[i] = node->out_of_place_digits[i - 8];
    node->message[10] = ' ';

    if (dev->head == NULL){
        dev->head = dev->tail = node;
        node->guess_count = 1;
    } else {
        dev->tail->next = node;
        node->guess_count = dev->tail->guess_count + 1;
        dev->tail = node;
    }

    guess_count_to_string(node);
    node->message[15] = '\n';

    printk(KERN_NOTICE "Tail:%s", dev->tail->guess);
    printk(KERN_NOTICE "Mmind Number:%s", dev->mmind_number);
    // Increase size of the guess info (One info contains 16 byte)
    dev->size += 16;
}


int mmind_trim(struct mmind_dev *dev)
{
    struct guess_node *temp, *deleted;
    temp = dev->head;
    while (temp){
        deleted = temp;
        temp = temp->next;
        kfree(deleted);
    }

    return 0;
}
void mmind_cleanup_module(void)
{
    dev_t devno = MKDEV(mmind_major, mmind_minor);

    if (mmind_devices) {
        int i;
        for (i = 0; i < mmind_nr_devs; i++) {
            mmind_trim(mmind_devices + i);
            cdev_del(&mmind_devices[i].cdev);
        }
    kfree(mmind_devices);
    }

    unregister_chrdev_region(devno, mmind_nr_devs);
}


int mmind_open(struct inode *inode, struct file *filp)
{
    struct mmind_dev *dev;
    
    dev = container_of(inode->i_cdev, struct mmind_dev, cdev);
    filp->private_data = dev;

    return 0;
}


int mmind_release(struct inode *inode, struct file *filp)
{
    return 0;
}


ssize_t mmind_read(struct file *filp, char __user *buf, size_t count,
                   loff_t *f_pos)
{
    struct mmind_dev *dev = filp->private_data;
    ssize_t retval = 0;
    int read_count;
    struct guess_node *temp;
    char *buffer;
    buffer = kmalloc(count * sizeof(char), GFP_KERNEL);
    if (down_interruptible(&dev->sem))
        return -ERESTARTSYS;

    if (*f_pos >= dev->size){
        up(&dev->sem);
        return retval;
    }

    if (*f_pos + count > dev->size)
        count = dev->size - *f_pos;

    read_count = 0;
    temp = dev->head;
    while(temp && temp->guess_count * 16 < *f_pos){
        temp = temp->next;
    }

    if(temp){
        int pos;
        pos = *f_pos - (temp->guess_count - 1) * 16;
        for(; pos < 16; pos++){
            buffer[read_count] = temp->message[pos];
            read_count ++;
            if (read_count == count){
                if (copy_to_user(buf, buffer, count)) {
                    up(&dev->sem);
                    return -EFAULT;
                }
                *f_pos += count;
                up(&dev->sem);
                return count;
            }
        }
        temp = temp->next;
    }

    while(temp)
    {
        int i;
        for(i = 0; i < 16; i++)
        {
            buffer[read_count] = temp->message[i];
            read_count ++;
            if(read_count == count)
                break;
        }
        if(read_count == count){
            break;
        }
        temp = temp->next;
    }

    if (copy_to_user(buf, buffer, count)) {
        up(&dev->sem);
        return -EFAULT;
    }

    *f_pos += count;
    up(&dev->sem);
    return count;
}


ssize_t mmind_write(struct file *filp, const char __user *buf, size_t count,
                    loff_t *f_pos)
{
    struct mmind_dev *dev = filp->private_data;
    char *guess;

    if (down_interruptible(&dev->sem))
        return -ERESTARTSYS;

    guess = kmalloc(sizeof(char) * (count), GFP_KERNEL);

    if (!guess)
        return -ENOMEM;

    printk(KERN_WARNING "%d, %s",count, buf);

    if (count != 5){
        up(&dev->sem);
        return -EINVAL;
    }

    if (copy_from_user(guess, buf, count)) {
        up(&dev->sem);
        return -EFAULT;
    }

    make_guess(dev, guess, count);
    kfree(guess);
  
    up(&dev->sem);
    return count;
}

long mmind_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	struct mmind_dev *dev = filp->private_data;
    int err = 0;
    int retval = 0;
    char __user *masterNo = (void *)0x0;
 
    if (_IOC_TYPE(cmd) != MMIND_IOC_MAGIC) return -ENOTTY;
 //   if (_IOC_NR(cmd) > MMIND_IOC_MAXNR) return -ENOTTY;

    if (_IOC_DIR(cmd) & _IOC_READ)
        err = !access_ok(VERIFY_WRITE, (void __user *)arg, _IOC_SIZE(cmd));

    else if (_IOC_DIR(cmd) & _IOC_WRITE)
        err =  !access_ok(VERIFY_READ, (void __user *)arg, _IOC_SIZE(cmd));

    if (err) return -EFAULT;

    switch(cmd) {
        case MMIND_REMAINING:
            if (! capable (CAP_SYS_ADMIN)) return -EPERM;   
            //bunu 10 yerine mmind_max_guesses yaparsın bişeler
            // senin arklar çözecek       
            return (10 - dev->tail->guess_count);
            break;
        case MMIND_ENDGAME:
            if (! capable (CAP_SYS_ADMIN)) return -EPERM;
            mmind_cleanup_module();
            break;
        case MMIND_NEWGAME:
            if (! capable (CAP_SYS_ADMIN)) return -EPERM;
            masterNo = kmalloc(sizeof(char) * 4, GFP_KERNEL);    
             // burda  bi cleanup çağırıp var olan herşeyi silip
             // başlatmak mantıklı      
			//mmind_cleanup_module();
			strncpy_from_user(masterNo, (const char __user *)arg, 4);
			printk(KERN_DEBUG "masterNo: %s",masterNo);
			//return masterNo;
			// 9876 veriyorum test.c den 4 haneyi compare ediyorum
			// eşitse masterNo içindeki 987 dönüyo
			// anca böyle debug edebildim amk ödevi :)
			// yani masterNo içinde terminalden verdiğin sayı kesin var
			// TEST edildi 
			// sen bu sayıyı sizin mastermind numaranıza set edeceksin burada
			if(strncmp("9876",masterNo,4)==0){
				return 9876;
			}else{
				return 55;
				}		
			// siz bunda tutuyormuşsunuz dev->mmind_number 
			//eşitledim burda bi kontrol edersin
			dev->mmind_number = masterNo;
            break;
        default:  /* redundant, as cmd was checked against MAXNR */
            return -ENOTTY;
    }
    return retval;
}


loff_t mmind_llseek(struct file *filp, loff_t off, int whence)
{
    struct mmind_dev *dev = filp->private_data;
    loff_t newpos;

    switch(whence) {
        case 0: /* SEEK_SET */
            newpos = off;
            break;

        case 1: /* SEEK_CUR */
            newpos = filp->f_pos + off;
            break;

        case 2: /* SEEK_END */
            newpos = dev->size + off;
            break;

        default: /* can't happen */
            return -EINVAL;
    }
    if (newpos < 0)
        return -EINVAL;
    filp->f_pos = newpos;
    return newpos;
}


struct file_operations mmind_fops = {
    .owner =    THIS_MODULE,
    .llseek =   mmind_llseek,
    .read =     mmind_read,
    .write =    mmind_write,
    .unlocked_ioctl =  mmind_ioctl,
    .open =     mmind_open,
    .release =  mmind_release,
};


int mmind_init_module(void)
{
    int result, i;
    
    dev_t devno = 0;

    if (mmind_major) {
        devno = MKDEV(mmind_major, mmind_minor);
        result = register_chrdev_region(devno, mmind_nr_devs, "mmind");
    } 
    else {
        result = alloc_chrdev_region(&devno, mmind_minor, mmind_nr_devs,
                                     "mmind");
        mmind_major = MAJOR(devno);
    }

    if (result < 0) {
        printk(KERN_WARNING "mmind: can't get major %d\n", mmind_major);
        return result;
    }

    mmind_devices = kmalloc(mmind_nr_devs * sizeof(struct mmind_dev),
                            GFP_KERNEL);

    if (!mmind_devices) {
        mmind_cleanup_module();
        return result;
    }

    memset(mmind_devices, 0, mmind_nr_devs * sizeof(struct mmind_dev));

    /* Initialize each device. */
    for (i = 0; i < mmind_nr_devs; i++) {
        int err;

        mmind_devices[i].size = 0;
        mmind_devices[i].head = NULL;
        mmind_devices[i].tail = NULL;
        mmind_devices[i].mmind_number = mmind_number;
        sema_init(&mmind_devices->sem,1);

        devno = MKDEV(mmind_major, mmind_minor + i);
        cdev_init(&mmind_devices->cdev, &mmind_fops);

        mmind_devices[i].cdev.owner = THIS_MODULE;
        mmind_devices[i].cdev.ops = &mmind_fops;

        err = cdev_add(&mmind_devices[i].cdev, devno, 1);

        if (err)
            printk(KERN_NOTICE "Error %d adding mmind%d", err, i);
    }

    return 0; /* succeed */
    
}

module_init(mmind_init_module);
module_exit(mmind_cleanup_module);
